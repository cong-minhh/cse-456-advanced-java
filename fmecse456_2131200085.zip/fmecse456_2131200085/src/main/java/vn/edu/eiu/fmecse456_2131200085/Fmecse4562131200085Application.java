package vn.edu.eiu.fmecse456_2131200085;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fmecse4562131200085Application {

	public static void main(String[] args) {
		SpringApplication.run(Fmecse4562131200085Application.class, args);
	}

}
