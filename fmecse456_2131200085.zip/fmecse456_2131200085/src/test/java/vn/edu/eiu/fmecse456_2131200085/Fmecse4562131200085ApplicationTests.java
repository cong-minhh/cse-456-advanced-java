package vn.edu.eiu.fmecse456_2131200085;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fmecse4562131200085ApplicationTests {

	@Test
	void contextLoads() {
	}

}
